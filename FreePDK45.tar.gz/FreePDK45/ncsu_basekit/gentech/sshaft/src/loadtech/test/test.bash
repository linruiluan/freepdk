export SSHAFT_TECHFILE=techfile.sshaft:tech2.sshaft
../loadtech

